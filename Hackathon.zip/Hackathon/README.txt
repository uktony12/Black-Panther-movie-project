Duy Le
Elyssa Ramos
Cynthia Nunez
Ukemeobong Anthony

Recipe Finder

Purpose: Input an ingredient one has and the program will find a n number of common ingredients.

Use: Run main.py. Input an ingredient (egg, potato, tomato) and a number (5, 7, 9) and hit submit. Note: more popular ingredients will take time to search.
After the n number of relevant ingredients are displayed, close the GUI and a youtube video of a recipe tutorial will automatically start downloading. This, too, will take a while to complete.

